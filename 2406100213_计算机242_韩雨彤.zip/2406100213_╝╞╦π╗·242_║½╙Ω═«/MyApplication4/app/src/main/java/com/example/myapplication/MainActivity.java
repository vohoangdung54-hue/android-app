package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private ArrayList<String> breadList = new ArrayList<>(Arrays.asList(
            "原味牛角包", "全麦吐司", "肉松小贝", "奶油餐包"));
    private HashMap<String, ArrayList<String>> evaluateMap = new HashMap<>();

    private ListView lvBread;
    private BreadAdapter adapter;
    private static final int REQUEST_EVALUATE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvBread = findViewById(R.id.lv_bread);
        EditText etAddBread = findViewById(R.id.et_add_bread);
        Button btnAdd = findViewById(R.id.btn_add);

        adapter = new BreadAdapter();
        lvBread.setAdapter(adapter);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etAddBread.getText().toString().trim();
                if (name.isEmpty()) {
                    Toast.makeText(MainActivity.this, "请输入面包名称", Toast.LENGTH_SHORT).show();
                    return;
                }
                breadList.add(name);
                adapter.notifyDataSetChanged();
                etAddBread.setText("");
                Toast.makeText(MainActivity.this, "添加成功", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void startEvaluateActivity(String breadName) {
        Intent intent = new Intent(MainActivity.this, EvaluateActivity.class);
        intent.putExtra("bread_name", breadName);
        startActivityForResult(intent, REQUEST_EVALUATE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_EVALUATE && resultCode == RESULT_OK && data != null) {
            String name = data.getStringExtra("bread_name");
            String score = data.getStringExtra("score");
            String tags = data.getStringExtra("tags");
            String channel = data.getStringExtra("channel");
            String shopName = data.getStringExtra("shop_name");
            String content = data.getStringExtra("content");
            String evaluate = "评分：" + score + "\n" +
                    "标签：" + tags + "\n" +
                    "渠道：" + channel + " | " + shopName + "\n" +
                    "评价：" + content;

            if (!evaluateMap.containsKey(name)) {
                evaluateMap.put(name, new ArrayList<>());
            }
            evaluateMap.get(name).add(evaluate);

            adapter.notifyDataSetChanged();
            Toast.makeText(this, "评价提交成功", Toast.LENGTH_SHORT).show();
        }
    }


    class BreadAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return breadList.size();
        }

        @Override
        public Object getItem(int position) {
            return breadList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            ViewHolder holder;
            if (convertView == null) {
                convertView = View.inflate(MainActivity.this, R.layout.item_bread, null);
                holder = new ViewHolder();
                holder.tvName = convertView.findViewById(R.id.tv_bread_name);
                holder.ibExpand = convertView.findViewById(R.id.ib_expand);
                holder.ibEvaluate = convertView.findViewById(R.id.ib_evaluate);
                holder.tvHistory = convertView.findViewById(R.id.tv_history);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            final String name = breadList.get(position);
            holder.tvName.setText(name);
            holder.tvHistory.setVisibility(View.GONE); // 滚动时默认收起

            // 下拉按钮：展开/收起历史评价
            holder.ibExpand.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (holder.tvHistory.getVisibility() == View.VISIBLE) {
                        holder.tvHistory.setVisibility(View.GONE);
                    } else {
                        ArrayList<String> history = evaluateMap.get(name);
                        if (history == null || history.isEmpty()) {
                            holder.tvHistory.setText("暂无评价记录");
                        } else {
                            StringBuilder sb = new StringBuilder();
                            for (int i = 0; i < history.size(); i++) {
                                sb.append("【第").append(i + 1).append("条】\n")
                                        .append(history.get(i))
                                        .append("\n\n");
                            }
                            holder.tvHistory.setText(sb.toString().trim());
                        }
                        holder.tvHistory.setVisibility(View.VISIBLE);
                    }
                }
            });


            holder.ibEvaluate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startEvaluateActivity(name);
                }
            });

            return convertView;
        }

        class ViewHolder {
            TextView tvName;
            ImageButton ibExpand;
            ImageButton ibEvaluate;
            TextView tvHistory;
        }
    }
}
