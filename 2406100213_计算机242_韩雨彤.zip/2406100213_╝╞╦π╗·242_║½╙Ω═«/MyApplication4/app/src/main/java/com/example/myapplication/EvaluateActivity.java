package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class EvaluateActivity extends AppCompatActivity {

    private TextView tvBreadName;
    private RadioGroup rgScore;
    private LinearLayout layoutGoodTags, layoutMidTags, layoutBadTags;

    private CheckBox cbSweet, cbSoft, cbPrice, cbSmell;
    private CheckBox cbTasteNormal, cbHard, cbPriceNormal, cbSizeNormal;
    private CheckBox cbTooSweet, cbDry, cbExpensive, cbNotFresh;

    private Spinner spChannel;
    private EditText etShopName;
    private EditText etContent;
    private Button btnSubmit;

    private String breadName;
    private String[] channelList = {"线下门店", "外卖平台", "线上网购"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evaluate);

        initView();
        breadName = getIntent().getStringExtra("bread_name");
        tvBreadName.setText("当前评价：" + breadName);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, channelList);
        spChannel.setAdapter(adapter);

        rgScore.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rb_good) {
                    layoutGoodTags.setVisibility(View.VISIBLE);
                    layoutMidTags.setVisibility(View.GONE);
                    layoutBadTags.setVisibility(View.GONE);
                } else if (checkedId == R.id.rb_mid) {
                    layoutGoodTags.setVisibility(View.GONE);
                    layoutMidTags.setVisibility(View.VISIBLE);
                    layoutBadTags.setVisibility(View.GONE);
                } else if (checkedId == R.id.rb_bad) {
                    layoutGoodTags.setVisibility(View.GONE);
                    layoutMidTags.setVisibility(View.GONE);
                    layoutBadTags.setVisibility(View.VISIBLE);
                }
            }
        });
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitResult();
            }
        });
    }

    private void initView() {
        tvBreadName = findViewById(R.id.tv_bread_name);
        rgScore = findViewById(R.id.rg_score);

        layoutGoodTags = findViewById(R.id.layout_good_tags);
        layoutMidTags = findViewById(R.id.layout_mid_tags);
        layoutBadTags = findViewById(R.id.layout_bad_tags);

        cbSweet = findViewById(R.id.cb_sweet);
        cbSoft = findViewById(R.id.cb_soft);
        cbPrice = findViewById(R.id.cb_price);
        cbSmell = findViewById(R.id.cb_smell);

        cbTasteNormal = findViewById(R.id.cb_taste_normal);
        cbHard = findViewById(R.id.cb_hard);
        cbPriceNormal = findViewById(R.id.cb_price_normal);
        cbSizeNormal = findViewById(R.id.cb_size_normal);

        cbTooSweet = findViewById(R.id.cb_too_sweet);
        cbDry = findViewById(R.id.cb_dry);
        cbExpensive = findViewById(R.id.cb_expensive);
        cbNotFresh = findViewById(R.id.cb_not_fresh);

        spChannel = findViewById(R.id.sp_channel);
        etShopName = findViewById(R.id.et_shop_name);
        etContent = findViewById(R.id.et_content);
        btnSubmit = findViewById(R.id.btn_submit);
    }

    private void submitResult() {
        int selectId = rgScore.getCheckedRadioButtonId();
        if (selectId == -1) {
            Toast.makeText(this, "请选择评分", Toast.LENGTH_SHORT).show();
            return;
        }
        String score = ((RadioButton) findViewById(selectId)).getText().toString();

        List<String> tagList = new ArrayList<>();
        if (selectId == R.id.rb_good) {
            if (cbSweet.isChecked()) tagList.add(cbSweet.getText().toString());
            if (cbSoft.isChecked()) tagList.add(cbSoft.getText().toString());
            if (cbPrice.isChecked()) tagList.add(cbPrice.getText().toString());
            if (cbSmell.isChecked()) tagList.add(cbSmell.getText().toString());
        } else if (selectId == R.id.rb_mid) {
            if (cbTasteNormal.isChecked()) tagList.add(cbTasteNormal.getText().toString());
            if (cbHard.isChecked()) tagList.add(cbHard.getText().toString());
            if (cbPriceNormal.isChecked()) tagList.add(cbPriceNormal.getText().toString());
            if (cbSizeNormal.isChecked()) tagList.add(cbSizeNormal.getText().toString());
        } else if (selectId == R.id.rb_bad) {
            if (cbTooSweet.isChecked()) tagList.add(cbTooSweet.getText().toString());
            if (cbDry.isChecked()) tagList.add(cbDry.getText().toString());
            if (cbExpensive.isChecked()) tagList.add(cbExpensive.getText().toString());
            if (cbNotFresh.isChecked()) tagList.add(cbNotFresh.getText().toString());
        }
        String tags = tagList.isEmpty() ? "无" : TextUtils.join("、", tagList);
        String channel = spChannel.getSelectedItem().toString();
        String shopName = etShopName.getText().toString().trim();
        if (shopName.isEmpty()) shopName = "未填写";
        String content = etContent.getText().toString().trim();
        if (content.isEmpty()) content = "无补充评价";
        Intent resultIntent = new Intent();
        resultIntent.putExtra("bread_name", breadName);
        resultIntent.putExtra("score", score);
        resultIntent.putExtra("tags", tags);
        resultIntent.putExtra("channel", channel);
        resultIntent.putExtra("shop_name", shopName);
        resultIntent.putExtra("content", content);

        setResult(RESULT_OK, resultIntent);
        finish();
    }
}
